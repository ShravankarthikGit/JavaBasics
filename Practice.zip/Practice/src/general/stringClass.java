package general;

public class stringClass {

}
